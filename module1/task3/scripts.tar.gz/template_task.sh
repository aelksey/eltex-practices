#!/bin/bash

if [[ $0 == "template_task.sh"  ]]; then
	echo "я бригадир, сам не работаю"
	exit 0
fi

out_file="report_"${0##*/}".log"
pid=$$
date=`date +%D`
time=`date +%T`

if [[ -e $out_file ]]; then
	echo "$pid" "$date" "$time" "Скрипт запущен" >> $out_file
else
	touch $out_file
	echo "$pid" "$date" "$time" "Скрипт запущен" >> $out_file
fi

max=1800
min=30
n=$(($RANDOM%($max-$min+1)+$min))
sleep $n

date=`date +%D`
time=`date +%T`

echo "$pid" "$date" "$time" "Скрипт завершился, работал" "$n" "секунд" >> $out_file




