#!/bin/bash

if [[ -e "observer.conf" ]] then
	
	while IFS= read -r line; do
  		if [[ `ls /proc | grep $line` != "" ]] then
			nohup ./$line >> "observer.log"
		fi
	done < "observer.conf"
else
	echo "No observer conf file exists"
	exit 1
fi


